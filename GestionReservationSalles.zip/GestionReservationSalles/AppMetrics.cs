﻿using Prometheus;

public static class AppMetrics
{
    public static readonly Counter ButtonClicks =
        Metrics.CreateCounter(
            "winforms_button_clicks_total",
            "Number of button clicks");

    public static readonly Gauge ActiveUsers =
        Metrics.CreateGauge(
            "winforms_active_users",
            "Current active users");

    public static readonly Histogram OperationDuration =
        Metrics.CreateHistogram(
            "winforms_operation_duration_seconds",
            "Operation duration");
}