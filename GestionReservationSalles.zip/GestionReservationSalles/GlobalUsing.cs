﻿global using global::System;
global using global::System.Collections.Generic;
global using global::System.Drawing;
global using global::System.IO;
global using global::System.Linq;
global using global::System.Net.Http;
global using global::System.Text;
global using global::System.Text.RegularExpressions;
global using global::System.Threading;
global using global::System.Threading.Tasks;
global using global::System.Windows.Forms;

global using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;
